# php_mysql_rest_api_crud
 php_mysql_rest_api_crud

## Tutoril Video
### https://www.youtube.com/watch?v=pqEONSbXeSQ
